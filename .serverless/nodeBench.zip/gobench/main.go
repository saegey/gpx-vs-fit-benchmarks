package gobench
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"time"

	"github.com/aws/aws-lambda-go/lambda"
)

var warm bool

type BenchResult struct {
	Format     string  `json:"format"`
	Parser     string  `json:"parser"`
	Iterations int     `json:"iterations"`
	MeanMS     float64 `json:"mean_ms"`
	P50MS      float64 `json:"p50_ms"`
	P95MS      float64 `json:"p95_ms"`
	MinMS      float64 `json:"min_ms"`
	MaxMS      float64 `json:"max_ms"`
}

func handler(ctx context.Context) (any, error) {
	commit := os.Getenv("COMMIT_SHA")
	if commit == "" { commit = "dev" }
	memStr := os.Getenv("AWS_LAMBDA_FUNCTION_MEMORY_SIZE")
	memory, _ := strconv.Atoi(memStr)

	out, err := exec.Command("./go-bench/run", "--json").Output() // your compiled bench
	if err != nil { return nil, err }

	now := time.Now().UnixMilli()

	for _, line := range splitLines(string(out)) {
		var r BenchResult
		if err := json.Unmarshal([]byte(line), &r); err != nil { continue }

		base := map[string]any{
			"ts": now, "lang": "Go", "memory_mb": memory, "cold": !warm, "commit": commit,
			"format": r.Format, "parser": r.Parser, "iterations": r.Iterations,
			"mean_ms": r.MeanMS, "p50_ms": r.P50MS, "p95_ms": r.P95MS, "min_ms": r.MinMS, "max_ms": r.MaxMS,
		}
		emf := map[string]any{
			"_aws": map[string]any{
				"Timestamp": now,
				"CloudWatchMetrics": []any{map[string]any{
					"Namespace": "GPXvsFIT/Benchmarks",
					"Dimensions": [][]string{{"Language","Format","Parser","MemoryMB","Cold"}},
					"Metrics": []any{
						map[string]any{"Name":"mean_ms","Unit":"Milliseconds"},
						map[string]any{"Name":"p50_ms","Unit":"Milliseconds"},
						map[string]any{"Name":"p95_ms","Unit":"Milliseconds"},
					},
				}},
			},
			"Language":"Go","Format":r.Format,"Parser":r.Parser,"MemoryMB":memory,"Cold":!warm,
			"mean_ms":r.MeanMS,"p50_ms":r.P50MS,"p95_ms":r.P95MS,
		}
		b1, _ := json.Marshal(emf);  fmt.Println(string(b1))
		b2, _ := json.Marshal(base); fmt.Println(string(b2))
	}
	warm = true
	return map[string]any{"ok": true}, nil
}

func splitLines(s string) []string {
	lines := []string{}
	cur := ""
	for _, r := range s {
		if r == '\n' || r == '\r' {
			if cur != "" { lines = append(lines, cur); cur = "" }
			continue
		}
		cur += string(r)
	}
	if cur != "" { lines = append(lines, cur) }
	return lines
}

func main(){ lambda.Start(handler) }